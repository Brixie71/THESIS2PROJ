# CCSStuff > 2024-03-22 3:04pm
https://universe.roboflow.com/customdatasetyolov8/ccsstuff

Provided by a Roboflow user
License: CC BY 4.0

